﻿namespace Artico.Infrastrucutre.Data
{
	public static class DataConstants
	{
		// article 
		public const int TitleMaxLength = 100;

		public const int JobMaxLength = 100;

		public const int PositionMaxLength = 100;
	}
}
