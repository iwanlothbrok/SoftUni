﻿namespace Artico.Core.Extensions
{
	public enum ArticleSorting
	{
		Order = 0,
		Title = 1,
		Job = 2,
		Position = 3
	}
}
