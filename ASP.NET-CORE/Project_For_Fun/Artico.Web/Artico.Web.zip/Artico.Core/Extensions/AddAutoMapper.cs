﻿namespace Artico.Core.Extensions
{
	internal class AddAutoMapper
	{
	}
}
