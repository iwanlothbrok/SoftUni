﻿namespace Artico.Core.Services.Users
{
	public interface IApplicationUserService
	{
		bool SetUserRole(string userId);
	}
}
