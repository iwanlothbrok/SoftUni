﻿namespace Artico.Web.Areas
{
	public static class Constants
	{
		public const string Admin = "Admin";

		public const string GlobalMessageKey = "GlobalMessage";
	}
}
