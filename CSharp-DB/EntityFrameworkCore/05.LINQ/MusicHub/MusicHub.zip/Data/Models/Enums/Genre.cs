﻿namespace MusicHub.Data.Models.Enums
{
    public enum  Genre
    {
            blues =0
            , rap = 1 
            , popmusic = 2
            , rock = 3
            , jazz = 4
    }
}
