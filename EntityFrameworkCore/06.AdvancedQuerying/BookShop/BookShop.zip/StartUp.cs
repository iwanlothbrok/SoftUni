﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();

            //  DbInitializer.ResetDatabase(db);
            System.Console.WriteLine(GetBooksByAgeRestriction(db, "miNor"));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var books = context.Books
            .ToList()
                .Where(ag => ag.AgeRestriction.ToString().Equals(command, StringComparison.OrdinalIgnoreCase))
                .Select(x=>new
                {
                    Title = x.Title,
                })           
            .OrderBy(t => t.Title)
            .ToList();

            var sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine(book.Title);
            }
            return sb.ToString().TrimEnd();
        }
    }
}
